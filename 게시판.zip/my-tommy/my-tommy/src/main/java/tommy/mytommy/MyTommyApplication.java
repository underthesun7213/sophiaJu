package tommy.mytommy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyTommyApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyTommyApplication.class, args);
	}
}
