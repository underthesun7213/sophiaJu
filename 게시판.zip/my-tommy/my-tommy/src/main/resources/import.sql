INSERT INTO article(id, title, content) VALUES (1, '가', '가가')
INSERT INTO article(id, title, content) VALUES (2, '나', '나나')
INSERT INTO article(id, title, content) VALUES (3, '다', '다다')