package tommy.mytommy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyTommyApplicationTests {

	@Test
	void contextLoads() {
	}

}
